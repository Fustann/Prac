const { app, BrowserWindow } = require('electron');
const path = require('node:path');
const os  = require('os-utils');

if (require('electron-squirrel-startup')) {
  app.quit();
}

const createWindow = () => {
  const mainWindow = new BrowserWindow({
    width: 1000,
    height: 600,
    icon: path.join(__dirname, "images.png"),
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, "index.html"));

  setInterval(() => {
    os.cpuUsage(function (v) {
      const cpuUsage = v * 100;
      const memUsage = os.freememPercentage() * 100;
      const totalMem = os.totalmem() / 1024; // GB
      const cpuCount = os.cpuCount();
      const platform = os.platform();
      const processUptime = os.processUptime();
      const systemUptime = os.sysUptime();

      console.log("CPU Usage (%): " + cpuUsage.toFixed(2));
      console.log("Mem Usage (%): " + memUsage.toFixed(2));
      console.log("Total Mem (GB): " + totalMem.toFixed(2));
      console.log("CPU Count: " + cpuCount);
      console.log("Platform: " + platform);
      console.log("Process Uptime (s): " + processUptime.toFixed(0));
      console.log("System Uptime (s): " + systemUptime.toFixed(0));

      mainWindow.webContents.send("cpu", cpuUsage);
      mainWindow.webContents.send("mem", memUsage);
      mainWindow.webContents.send("total-mem", totalMem);
      mainWindow.webContents.send("cpu-count", cpuCount);
      mainWindow.webContents.send("platform", platform);
      mainWindow.webContents.send("process-uptime", processUptime);
      mainWindow.webContents.send("system-uptime", systemUptime);
    });
  }, 1000); 
};

module.exports = { createWindow };

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});